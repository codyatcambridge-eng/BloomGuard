/**
 * BloomGuard Resilient Blur Layer
 *
 * Applies hard blur to both current and replacement media nodes and installs a persistent
 * absolute overlay fallback (`.bg-blur-overlay`) so blur survives YouTube static->video swaps.
 *
 * NSFWJS integration:
 * - After a positive classification, call `applyResilientBlurToContainer(container, videoId)`.
 * - Observer/heartbeat should call same function repeatedly for owned containers.
 */

import {
  BG_OWNED_ATTR,
  BG_VIDEO_ID_ATTR,
  stampOwnership,
} from "./ownership";

export const BG_OVERLAY_CLASS = "bg-blur-overlay";
const BG_STYLE_ID = "bg-blur-style-v1";
const BLUR_TOKEN = "blur(35px)";

const MEDIA_SELECTOR = [
  "img",
  "video",
  "#thumbnail",
  "yt-image",
  "yt-img-shadow",
  "img[src*='i.ytimg.com']",
].join(",");

export function ensureBlurStylesInjected(): void {
  if (document.getElementById(BG_STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = BG_STYLE_ID;
  style.textContent = `
    [${BG_OWNED_ATTR}="1"] #thumbnail,
    [${BG_OWNED_ATTR}="1"] img,
    [${BG_OWNED_ATTR}="1"] video,
    [${BG_OWNED_ATTR}="1"] yt-image,
    [${BG_OWNED_ATTR}="1"] yt-img-shadow {
      filter: ${BLUR_TOKEN} !important;
      -webkit-filter: ${BLUR_TOKEN} !important;
      backdrop-filter: ${BLUR_TOKEN} !important;
      -webkit-backdrop-filter: ${BLUR_TOKEN} !important;
    }
    .${BG_OVERLAY_CLASS} {
      position: absolute !important;
      inset: 0 !important;
      pointer-events: none !important;
      backdrop-filter: ${BLUR_TOKEN} !important;
      -webkit-backdrop-filter: ${BLUR_TOKEN} !important;
      background: rgba(0,0,0,0.06) !important;
      z-index: 9998 !important;
      border-radius: inherit !important;
    }
  `;
  (document.head || document.documentElement).appendChild(style);
}

function ensureContainerPositioning(container: Element): void {
  const el = container as HTMLElement;
  const computed = window.getComputedStyle(el);
  if (computed.position === "static" || !computed.position) {
    el.style.setProperty("position", "relative", "important");
  }
  el.style.setProperty("overflow", "hidden", "important");
}

function forceBlurNode(node: Element): void {
  const el = node as HTMLElement;
  el.style.setProperty("filter", BLUR_TOKEN, "important");
  el.style.setProperty("-webkit-filter", BLUR_TOKEN, "important");
  el.style.setProperty("backdrop-filter", BLUR_TOKEN, "important");
  el.style.setProperty("-webkit-backdrop-filter", BLUR_TOKEN, "important");
}

function ensureOverlay(container: Element): HTMLElement {
  let overlay = container.querySelector(`:scope > .${BG_OVERLAY_CLASS}`) as HTMLElement | null;
  if (overlay && overlay.isConnected) return overlay;

  overlay = document.createElement("div");
  overlay.className = BG_OVERLAY_CLASS;
  overlay.setAttribute("aria-hidden", "true");
  container.appendChild(overlay);
  return overlay;
}

function matchMediaNodes(container: Element, videoId: string): Element[] {
  const all = Array.from(container.querySelectorAll(MEDIA_SELECTOR));
  if (!videoId) return all;
  return all.filter((node) => {
    const src = String(
      (node as HTMLImageElement).currentSrc ||
        node.getAttribute("src") ||
        node.getAttribute("poster") ||
        ""
    );
    return !src || src.includes(videoId) || src.includes("i.ytimg.com");
  });
}

export function applyResilientBlurToContainer(container: Element, videoId: string): void {
  try {
    if (!container) return;
    ensureBlurStylesInjected();
    stampOwnership(container, videoId);
    ensureContainerPositioning(container);

    const ownedId = String(container.getAttribute(BG_VIDEO_ID_ATTR) || videoId || "");
    const mediaNodes = matchMediaNodes(container, ownedId);
    for (const node of mediaNodes) forceBlurNode(node);
    ensureOverlay(container);
  } catch {
    // Fail-open behavior at runtime, no throw in content script.
  }
}

export function clearBlurFromContainer(container: Element): void {
  try {
    const nodes = container.querySelectorAll(MEDIA_SELECTOR);
    nodes.forEach((node) => {
      const el = node as HTMLElement;
      el.style.removeProperty("filter");
      el.style.removeProperty("-webkit-filter");
      el.style.removeProperty("backdrop-filter");
      el.style.removeProperty("-webkit-backdrop-filter");
    });
    const overlay = container.querySelector(`:scope > .${BG_OVERLAY_CLASS}`);
    if (overlay?.parentElement) overlay.parentElement.removeChild(overlay);
  } catch {
    // no-op
  }
}

/**
 * Helper for scanner callback:
 * - Pass the positively-classified media node and extracted `videoId`.
 * - This resolves to a robust container and applies ownership+blur.
 */
export function applyBlurFromDetectedNode(node: Element, videoId: string): Element | null {
  if (!node || !videoId) return null;
  const container =
    node.closest(
      [
        "ytd-rich-item-renderer",
        "ytd-video-renderer",
        "ytd-compact-video-renderer",
        "ytd-grid-video-renderer",
        "yt-lockup-view-model",
        "ytd-reel-item-renderer",
        "ytd-reel-shelf-renderer",
        "ytm-rich-item-renderer",
        "ytm-video-with-context-renderer",
        "ytm-compact-video-renderer",
        "ytm-shorts-lockup-view-model",
        "ytm-reel-video-renderer",
        "#shorts-player",
        "#content",
      ].join(",")
    ) || node;

  applyResilientBlurToContainer(container, videoId);
  return container;
}

/**
 * WebView testing notes:
 * - Desktop: hover a blurred thumbnail until preview video appears; blur + overlay should persist.
 * - Infinite feed: scroll until DOM recycles prior cards; overlay must remain attached to newly stamped owned card.
 * - Mobile WebView (`m.youtube.com`): shorts transitions should keep blur on `ytm-reel-video-renderer` swaps.
 */

