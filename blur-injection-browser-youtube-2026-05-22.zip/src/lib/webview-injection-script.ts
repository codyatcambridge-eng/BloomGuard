export interface InjectionConfig {
  sensitivity: number;
  blurStrength: number;
  enabled: boolean;
  forcedBlur?: boolean;
  failClosed?: boolean;
  debug?: boolean;
  nonce: string;
  blockingMode?: 'mvp' | 'full';
  pageEpoch?: number;
  diagYouTubeShorts?: boolean;
  enableShortsHealthHeal?: boolean;
  regularCardControllerShadowMode?: boolean;
  regularCardControllerEnabled?: boolean;
}

export interface FailOpenModePolicyInput {
  rawShouldBlur: boolean;
  normalizedCategory: string;
  predictedLabel: string;
  isErrorResult: boolean;
  failClosed: boolean;
  enabled: boolean;
  sensitivity: number;
  blockingMode?: 'mvp' | 'full';
}

export interface AnatomicalPolicyInput {
  shouldApplyBlur: boolean;
  predictedLabel: string;
  sexyScore: number | null;
  pornScore: number | null;
  anatomicalThreshold: number;
  forceUnsafe: boolean;
  failClosed: boolean;
  enabled: boolean;
  sensitivity: number;
}

const MVP_UNSAFE_CATEGORIES = new Set([
  'swimwear',
  'shirtless',
  'shirtless_male',
  'bikini',
  'swim_trunks',
  'sports_bra',
  'thirst',
]);

function normalizePolicyLabel(label: string): string {
  return String(label || '').trim().toLowerCase();
}

function isMvpAllowedPolicyLabel(label: string): boolean {
  const normalized = normalizePolicyLabel(label);
  return MVP_UNSAFE_CATEGORIES.has(normalized) || normalized === 'porn' || normalized === 'hentai';
}

export function applyFailOpenAndModePolicyDecision(input: FailOpenModePolicyInput): { shouldBlur: boolean; reason: string | null } {
  const normalizedCategory = normalizePolicyLabel(input.normalizedCategory);
  const predictedLabel = normalizePolicyLabel(input.predictedLabel);
  const enabledAndActive = input.enabled && input.sensitivity > 0;

  if (input.isErrorResult) {
    if (input.failClosed && enabledAndActive) {
      return { shouldBlur: true, reason: 'failClosed/' + normalizedCategory };
    }
    return { shouldBlur: false, reason: 'failOpen/' + normalizedCategory };
  }

  if (input.blockingMode === 'mvp') {
    const categoryAllowed = isMvpAllowedPolicyLabel(normalizedCategory);
    const predictedAllowed = isMvpAllowedPolicyLabel(predictedLabel);
    if (input.rawShouldBlur && !categoryAllowed && !predictedAllowed) {
      return { shouldBlur: false, reason: 'mvp_filter/' + (normalizedCategory || predictedLabel || 'unknown') };
    }
  }

  return { shouldBlur: !!input.rawShouldBlur, reason: null };
}

export function applyAnatomicalThresholdDecision(input: AnatomicalPolicyInput): { shouldBlur: boolean; reason: string | null } {
  if (!input.shouldApplyBlur || input.forceUnsafe) {
    return { shouldBlur: !!input.shouldApplyBlur, reason: null };
  }
  if (input.predictedLabel !== 'sexy' && input.predictedLabel !== 'porn') {
    return { shouldBlur: !!input.shouldApplyBlur, reason: null };
  }

  const score = input.predictedLabel === 'sexy' ? input.sexyScore : input.pornScore;
  if (score === null || !Number.isFinite(score)) {
    if (input.failClosed && input.enabled && input.sensitivity > 0) {
      return { shouldBlur: true, reason: input.predictedLabel + '_scoreNaN/failClosed' };
    }
    return { shouldBlur: false, reason: input.predictedLabel + '_scoreNaN/failOpen' };
  }

  if (score < input.anatomicalThreshold) {
    return { shouldBlur: false, reason: input.predictedLabel + '<anatomicalThreshold' };
  }

  return { shouldBlur: true, reason: null };
}

export function getCategoryThresholds(dialLevel: number): { porn: number; sexy: number; hentai: number } {
  switch (dialLevel) {
    case 0: return { porn: 1.1, sexy: 1.1, hentai: 1.1 };
    case 1: return { porn: 0.7, sexy: 0.85, hentai: 0.7 };
    case 2: return { porn: 0.5, sexy: 0.65, hentai: 0.5 };
    case 3: return { porn: 0.3, sexy: 0.45, hentai: 0.3 };
    case 4: return { porn: 0.15, sexy: 0.25, hentai: 0.15 };
    default: return { porn: 0.3, sexy: 0.45, hentai: 0.3 };
  }
}

export function generateModerationScript(config: InjectionConfig): string {
  const nonce = config.nonce || 'n_' + Math.random().toString(36).slice(2, 10);
  const requestedBlurStrength = Number.isFinite(config.blurStrength) ? Number(config.blurStrength) : 35;
  const clampBlurStrength = Math.max(0, Math.min(35, requestedBlurStrength));
  const pageEpoch = Number.isFinite(config.pageEpoch) ? Number(config.pageEpoch) : Date.now();

  return `
;(function() {
  'use strict';
  console.log('[BloomGuard] Injection successful v20260522-mvp-fix');
  console.log('[BloomGuard] IIFE start - lightweight mode');

  if (window.__MW_ACTIVE__) {
    console.log('[MW] Already injected, skipping');
    try {
      if (window.__MW_BLUR_OVERLAY_API__ && typeof window.__MW_BLUR_OVERLAY_API__.sendReady === 'function') {
        window.__MW_BLUR_OVERLAY_API__.sendReady('reinject');
      }
    } catch (e) {}
    return 'MW_ALREADY_ACTIVE';
  }
  window.__MW_ACTIVE__ = true;

  var CONFIG = {
    nonce: '${nonce}',
    enabled: ${config.enabled ? 'true' : 'false'},
    sensitivity: ${Math.max(0, Number(config.sensitivity || 0))},
    blurStrength: ${clampBlurStrength},
    pageEpoch: ${pageEpoch},
    blockingMode: '${config.blockingMode || 'mvp'}',
    debug: ${config.debug ? 'true' : 'false'}
  };

  var BG_OWNED_ATTR = 'data-bg-owned';
  var BG_VIDEO_ID_ATTR = 'data-bg-video-id';
  var OVERLAY_CLASS = 'bg-blur-overlay';
  var mediaSelector = 'img, video, #thumbnail';

  function postToHost(payload) {
    try {
      if (window.mobileApp && typeof window.mobileApp.postMessage === 'function') {
        window.mobileApp.postMessage({ detail: payload });
      }
    } catch (e) {}
    try { window.postMessage(payload, '*'); } catch (e) {}
    try {
      if (window.parent && window.parent !== window) window.parent.postMessage(payload, '*');
    } catch (e) {}
  }

  function sendBlurReady(reason) {
    postToHost({
      type: 'MW_BLUR_READY',
      reason: reason || 'ready',
      url: window.location.href,
      timestamp: Date.now(),
      pageEpoch: CONFIG.pageEpoch
    });
  }

  function findCardContainer(node) {
    if (!node || node.nodeType !== 1) return null;
    var selectors = [
      'ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-compact-video-renderer',
      'ytd-grid-video-renderer', 'yt-lockup-view-model',
      'ytm-rich-item-renderer', 'ytm-video-with-context-renderer', 'ytm-compact-video-renderer',
      'ytm-reel-video-renderer', 'ytm-shorts-lockup-view-model', '#shorts-player', '#content'
    ].join(',');
    return node.closest(selectors) || node;
  }

  function ensureContainerPositioning(container) {
    if (!container || container.nodeType !== 1) return;
    var cs = window.getComputedStyle(container);
    if (!cs.position || cs.position === 'static') {
      container.style.setProperty('position', 'relative', 'important');
    }
    container.style.setProperty('overflow', 'hidden', 'important');
  }

  function ensureOverlay(container) {
    var overlay = container.querySelector(':scope > .' + OVERLAY_CLASS);
    if (overlay && overlay.isConnected) return overlay;
    overlay = document.createElement('div');
    overlay.className = OVERLAY_CLASS;
    overlay.setAttribute('aria-hidden', 'true');
    overlay.style.cssText = [
      'position:absolute!important',
      'inset:0!important',
      'z-index:9998!important',
      'pointer-events:none!important',
      'background:rgba(0,0,0,0.78)!important',
      'mix-blend-mode:multiply!important'
    ].join(';');
    container.appendChild(overlay);
    return overlay;
  }

  function applyNodeBlur(node) {
    if (!node || node.nodeType !== 1) return;
    node.style.setProperty('filter', 'blur(35px)', 'important');
    node.style.setProperty('-webkit-filter', 'blur(35px)', 'important');
  }

  function applyResilientBlur(container, videoId) {
    if (!container || container.nodeType !== 1) return;
    container.setAttribute(BG_OWNED_ATTR, '1');
    if (videoId) container.setAttribute(BG_VIDEO_ID_ATTR, String(videoId));
    ensureContainerPositioning(container);
    var nodes = container.querySelectorAll(mediaSelector);
    nodes.forEach(function(node) { applyNodeBlur(node); });
    container.querySelectorAll('img, video, #thumbnail').forEach(function(node) { applyNodeBlur(node); });
    ensureOverlay(container);
  }

  function reapplyAllOwnedBlurs(reason) {
    var owned = document.querySelectorAll('[' + BG_OWNED_ATTR + '="1"]');
    owned.forEach(function(container) {
      var vid = container.getAttribute(BG_VIDEO_ID_ATTR) || '';
      applyResilientBlur(container, vid);
    });
    if (CONFIG.debug) console.log('[BloomGuard] reapply owned', reason || 'unknown', 'count=' + owned.length);
  }

  window.__MW_APPLY_RESILIENT_BLUR__ = function(nodeOrContainer, srcOrVideoId) {
    try {
      var target = findCardContainer(nodeOrContainer) || nodeOrContainer;
      var candidate = String(srcOrVideoId || '');
      applyResilientBlur(target, candidate);
      return true;
    } catch (e) {
      return false;
    }
  };

  window.__MW_CLEAR_BLUR__ = function(node) {
    try {
      var target = findCardContainer(node) || node;
      if (target && target.getAttribute && target.getAttribute(BG_OWNED_ATTR) === '1') {
        var vid = target.getAttribute(BG_VIDEO_ID_ATTR) || '';
        applyResilientBlur(target, vid);
        console.log('[BloomGuard] legacy clear blocked on owned container');
        return false;
      }
    } catch (e) {}
    return false;
  };
  window.__MW_LEGACY_CLEAR__ = window.__MW_CLEAR_BLUR__;

  var pendingByRequestId = Object.create(null);

  function buildScanItems() {
    var candidates = Array.from(document.querySelectorAll('img[src],video[poster],video[src],#thumbnail img[src],#thumbnail'));
    var seen = new Set();
    var items = [];
    for (var i = 0; i < candidates.length && items.length < 24; i += 1) {
      var el = candidates[i];
      if (!el || el.nodeType !== 1) continue;
      var src = String(el.currentSrc || el.getAttribute('src') || el.getAttribute('poster') || '');
      if (!src || seen.has(src)) continue;
      seen.add(src);
      var rect = el.getBoundingClientRect();
      if (!rect || rect.width < 40 || rect.height < 40) continue;
      var itemId = 'mw_' + Math.random().toString(36).slice(2, 10);
      el.setAttribute('data-mw-item-id', itemId);
      items.push({ itemId: itemId, src: src, sourceType: 'media' });
    }
    return items;
  }

  function requestScan(reason) {
    if (!CONFIG.enabled || CONFIG.sensitivity <= 0) return;
    var items = buildScanItems();
    if (!items.length) return;
    var requestId = 'req_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    pendingByRequestId[requestId] = true;
    postToHost({
      type: 'gc-moderation-request',
      action: 'scan',
      requestId: requestId,
      nonce: CONFIG.nonce,
      pageEpoch: CONFIG.pageEpoch,
      thresholds: { porn: 0.3, sexy: 0.45, hentai: 0.3 },
      items: items
    });
    if (CONFIG.debug) console.log('[BloomGuard] scan request', reason || 'unknown', 'items=' + items.length);
  }

  function onModerationResult(message) {
    if (!message || message.type !== 'gc-moderation-result') return;
    if (message.nonce !== CONFIG.nonce) return;
    if (!pendingByRequestId[message.requestId]) return;
    delete pendingByRequestId[message.requestId];
    var results = Array.isArray(message.results) ? message.results : [];
    for (var i = 0; i < results.length; i += 1) {
      var result = results[i];
      if (!result || !result.shouldBlur) continue;
      var node = document.querySelector('[data-mw-item-id="' + String(result.itemId || '') + '"]');
      if (!node) continue;
      var container = findCardContainer(node) || node;
      applyResilientBlur(container, String(result.itemId || ''));
    }
  }

  function onMessage(event) {
    var data = event && event.data && typeof event.data === 'object' ? event.data : null;
    if (!data) return;
    onModerationResult(data);
    if (data.type === 'MW_BLUR_COMMAND' && data.command === 'PING') {
      sendBlurReady('ping');
    }
  }

  window.addEventListener('message', onMessage);
  window.addEventListener('messageFromNative', function(event) {
    var data = event && event.detail && typeof event.detail === 'object' ? event.detail : (event && event.data);
    if (data && typeof data === 'object') onModerationResult(data);
  });

  var ownedObserver = new MutationObserver(function(mutations) {
    for (var i = 0; i < mutations.length; i += 1) {
      var m = mutations[i];
      if (m.type === 'childList' || m.type === 'attributes') {
        reapplyAllOwnedBlurs('owned_observer');
        break;
      }
    }
  });
  try {
    ownedObserver.observe(document.documentElement || document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['src', 'poster', 'style', 'class']
    });
  } catch (e) {}

  window.addEventListener('yt-navigate-finish', function() {
    console.log('[BloomGuard] yt-navigate-finish lightweight reinject hook');
    requestScan('yt-navigate-finish');
    reapplyAllOwnedBlurs('yt-navigate-finish');
    sendBlurReady('yt-navigate-finish');
  });
  window.addEventListener('pageshow', function() { sendBlurReady('pageshow'); });
  window.addEventListener('load', function() { sendBlurReady('load'); });
  document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
      reapplyAllOwnedBlurs('visibility');
      sendBlurReady('visibility');
    }
  });

  requestScan('init');
  sendBlurReady('init');

  window.__MW_TEARDOWN__ = function() {
    try { ownedObserver.disconnect(); } catch (e) {}
    try { window.removeEventListener('message', onMessage); } catch (e) {}
    window.__MW_ACTIVE__ = false;
  };

  return 'MW_INJECTED';
})();
`;
}
