/**
 * BloomGuard Observer + Heartbeat
 *
 * Implements:
 * - MutationObserver on `document.body`
 * - attributes watched: src, poster, style, class, selected, is-active
 * - debounce at ~120ms
 * - `yt-navigate-finish` forced rescan + reapply
 * - 5-second heartbeat calling `reapplyAllBlurs()`
 *
 * NSFWJS integration:
 * - Provide `onCandidateNode(node)` from scanner queue flow (classification pipeline).
 * - Provide `onRescanRequested()` to trigger your existing NSFWJS re-scan pass.
 */

import {
  bumpOwnershipEpoch,
  getOwnedRecords,
  reapplyAllBlurs,
  refreshOwnedContainersFromDom,
} from "./ownership";
import { applyResilientBlurToContainer, ensureBlurStylesInjected } from "./blur";

type ObserverBootstrapOptions = {
  onCandidateNode?: (node: Element) => void;
  onRescanRequested?: (reason: string) => void;
  log?: (msg: string, ...args: unknown[]) => void;
};

type RuntimeHandles = {
  disconnect: () => void;
};

const ATTR_FILTER = ["src", "poster", "style", "class", "selected", "is-active"];
const DEBOUNCE_MS = 120;
const HEARTBEAT_MS = 5000;

const CANDIDATE_SELECTOR = [
  // desktop cards
  "ytd-rich-item-renderer",
  "ytd-video-renderer",
  "ytd-compact-video-renderer",
  "ytd-grid-video-renderer",
  "yt-lockup-view-model",
  "ytd-reel-item-renderer",
  "ytd-reel-shelf-renderer",
  // mobile cards
  "ytm-rich-item-renderer",
  "ytm-video-with-context-renderer",
  "ytm-compact-video-renderer",
  "ytm-shorts-lockup-view-model",
  "ytm-reel-video-renderer",
  "#shorts-player",
  // media fallback
  "img[src*='i.ytimg.com']",
  "img[src*='ytimg.com']",
  "video",
].join(",");

function safeLog(log: ObserverBootstrapOptions["log"], msg: string, ...args: unknown[]): void {
  try {
    if (typeof log === "function") log(msg, ...args);
  } catch {
    // no-op
  }
}

function collectCandidatesFromNode(node: Element): Element[] {
  const out: Element[] = [];
  if (node.matches(CANDIDATE_SELECTOR)) out.push(node);
  if (typeof node.querySelectorAll === "function") {
    node.querySelectorAll(CANDIDATE_SELECTOR).forEach((n) => out.push(n));
  }
  return out;
}

function reapplyFromOwnership(log?: ObserverBootstrapOptions["log"]): void {
  reapplyAllBlurs((container, videoId) => {
    applyResilientBlurToContainer(container, videoId);
  });
  safeLog(log, "[BloomGuard] reapplyAllBlurs complete; ownedRecords=%d", getOwnedRecords().length);
}

function hardRescanAndReapply(reason: string, options: ObserverBootstrapOptions): void {
  bumpOwnershipEpoch();
  for (const record of getOwnedRecords()) {
    refreshOwnedContainersFromDom(record.videoId);
  }
  reapplyFromOwnership(options.log);
  try {
    options.onRescanRequested?.(reason);
  } catch {
    // keep observer alive
  }
}

export function bootstrapBloomGuardObserver(options: ObserverBootstrapOptions = {}): RuntimeHandles {
  ensureBlurStylesInjected();

  const pendingNodes = new Set<Element>();
  let debounceTimer: number | null = null;
  let heartbeatTimer: number | null = null;

  const flush = (reason: string): void => {
    const batch = Array.from(pendingNodes);
    pendingNodes.clear();
    if (batch.length < 1) return;

    for (const node of batch) {
      try {
        options.onCandidateNode?.(node);
      } catch {
        // ignore per-node scanner exceptions
      }
    }

    safeLog(options.log, "[BloomGuard] observer flush reason=%s candidates=%d", reason, batch.length);
    reapplyFromOwnership(options.log);
  };

  const scheduleFlush = (reason: string): void => {
    if (debounceTimer !== null) window.clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => {
      debounceTimer = null;
      flush(reason);
    }, DEBOUNCE_MS);
  };

  const enqueueNode = (node: Element, reason: string): void => {
    for (const candidate of collectCandidatesFromNode(node)) pendingNodes.add(candidate);
    scheduleFlush(reason);
  };

  // Initial seed scan for current viewport/feed content.
  try {
    document.querySelectorAll(CANDIDATE_SELECTOR).forEach((n) => pendingNodes.add(n));
    scheduleFlush("bootstrap");
  } catch {
    // ignore bootstrap query errors
  }

  const observer = new MutationObserver((mutations) => {
    try {
      for (const mutation of mutations) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((n) => {
            if (n.nodeType === 1) enqueueNode(n as Element, "childList");
          });
        } else if (mutation.type === "attributes" && mutation.target && mutation.target.nodeType === 1) {
          const attr = String(mutation.attributeName || "");
          if (!ATTR_FILTER.includes(attr)) continue;
          enqueueNode(mutation.target as Element, `attr:${attr}`);
        }
      }
    } catch {
      // never allow observer callback to throw
    }
  });

  try {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ATTR_FILTER,
    });
  } catch (error) {
    safeLog(options.log, "[BloomGuard] observer attach failed: %o", error);
  }

  const onYtNavigateFinish = (): void => {
    hardRescanAndReapply("yt-navigate-finish", options);
    // aggressively seed candidates from new route tree
    try {
      document.querySelectorAll(CANDIDATE_SELECTOR).forEach((n) => pendingNodes.add(n));
      scheduleFlush("yt-navigate-finish");
    } catch {
      // no-op
    }
  };

  const onPopState = (): void => {
    hardRescanAndReapply("popstate", options);
  };

  window.addEventListener("yt-navigate-finish", onYtNavigateFinish as EventListener, { passive: true });
  window.addEventListener("popstate", onPopState, { passive: true });

  heartbeatTimer = window.setInterval(() => {
    try {
      reapplyFromOwnership(options.log);
    } catch {
      // keep heartbeat alive
    }
  }, HEARTBEAT_MS);

  const disconnect = (): void => {
    try {
      observer.disconnect();
    } catch {
      // no-op
    }
    if (debounceTimer !== null) {
      window.clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    if (heartbeatTimer !== null) {
      window.clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
    window.removeEventListener("yt-navigate-finish", onYtNavigateFinish as EventListener);
    window.removeEventListener("popstate", onPopState);
  };

  return { disconnect };
}

/**
 * WebView testing notes:
 * - Scroll test: rapidly scroll Home/Search so nodes churn; ensure observer keeps queuing new candidates.
 * - Navigation test: click into video, back to feed, switch tabs (Home/Subscriptions/Search), verify
 *   `yt-navigate-finish` path triggers forced re-scan and blur reapply.
 * - Hover/preview test: desktop thumbnail->preview transitions should re-enter via attribute mutations.
 * - Infinite feed test: run 3-5 minutes; verify heartbeat recovers any lost blur from delayed swaps.
 */

