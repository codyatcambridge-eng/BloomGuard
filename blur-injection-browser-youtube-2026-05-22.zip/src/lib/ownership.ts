/**
 * BloomGuard Ownership Core
 *
 * Strong ownership layer to survive YouTube node churn (thumbnail->preview video swaps,
 * card recycling, infinite feed rerenders). This module is intentionally DOM-focused and
 * can run in WebView content-script environments.
 *
 * NSFWJS integration:
 * - Call `stampOwnership(container, videoId)` immediately after a positive classification.
 * - Call `registerOwnedVideo(videoId, container)` from your classifier result handler.
 * - `reapplyAllBlurs()` can be called by observer heartbeat or navigation hooks.
 */

export const BG_OWNED_ATTR = "data-bg-owned";
export const BG_VIDEO_ID_ATTR = "data-bg-video-id";
export const BG_EPOCH_ATTR = "data-bg-epoch";

export const BG_ACTIVE_EPOCH: { value: number } = { value: Date.now() };

type OwnedRecord = {
  videoId: string;
  epoch: number;
  containers: Set<Element>;
  updatedAt: number;
};

const ownedByVideoId = new Map<string, OwnedRecord>();
const TTL_MS = 1000 * 60 * 30; // 30 min

export function setOwnershipEpoch(epoch: number): void {
  if (Number.isFinite(epoch) && epoch > 0) BG_ACTIVE_EPOCH.value = Math.floor(epoch);
}

export function bumpOwnershipEpoch(): number {
  BG_ACTIVE_EPOCH.value = Date.now();
  return BG_ACTIVE_EPOCH.value;
}

export function getOwnershipEpoch(): number {
  return BG_ACTIVE_EPOCH.value;
}

export function isValidVideoId(videoId: string): boolean {
  const id = String(videoId || "").trim();
  return /^[A-Za-z0-9_-]{6,15}$/.test(id);
}

export function extractVideoIdFromAnyNode(node: Element | null): string {
  if (!node) return "";
  const direct = String(node.getAttribute(BG_VIDEO_ID_ATTR) || "");
  if (isValidVideoId(direct)) return direct;

  const media = node.matches("img,video")
    ? node
    : (node.querySelector("img[src*='ytimg.com'],video[src],video[poster]") as Element | null);
  if (!media) return "";

  const src = String(
    (media as HTMLImageElement).currentSrc ||
      media.getAttribute("src") ||
      media.getAttribute("poster") ||
      ""
  );
  const m1 = src.match(/\/vi\/([A-Za-z0-9_-]{6,15})\//);
  if (m1?.[1]) return m1[1];
  const m2 = src.match(/[?&]v=([A-Za-z0-9_-]{6,15})/);
  if (m2?.[1]) return m2[1];
  return "";
}

export function stampOwnership(container: Element, videoId: string): boolean {
  try {
    if (!container || !isValidVideoId(videoId)) return false;
    const epoch = BG_ACTIVE_EPOCH.value;
    container.setAttribute(BG_OWNED_ATTR, "1");
    container.setAttribute(BG_VIDEO_ID_ATTR, videoId);
    container.setAttribute(BG_EPOCH_ATTR, String(epoch));
    return true;
  } catch {
    return false;
  }
}

export function registerOwnedVideo(videoId: string, container: Element): boolean {
  if (!isValidVideoId(videoId) || !container) return false;
  const stamped = stampOwnership(container, videoId);
  if (!stamped) return false;

  const now = Date.now();
  const epoch = BG_ACTIVE_EPOCH.value;
  const existing = ownedByVideoId.get(videoId);
  if (existing) {
    existing.epoch = epoch;
    existing.updatedAt = now;
    existing.containers.add(container);
    return true;
  }

  ownedByVideoId.set(videoId, {
    videoId,
    epoch,
    containers: new Set([container]),
    updatedAt: now,
  });
  return true;
}

export function getOwnedRecords(): OwnedRecord[] {
  pruneOwnedRegistry();
  return Array.from(ownedByVideoId.values());
}

export function getOwnedContainersForVideo(videoId: string): Element[] {
  const rec = ownedByVideoId.get(videoId);
  if (!rec) return [];
  const out: Element[] = [];
  rec.containers.forEach((c) => {
    if (c && c.isConnected) out.push(c);
  });
  return out;
}

export function pruneOwnedRegistry(): void {
  const now = Date.now();
  for (const [videoId, rec] of ownedByVideoId.entries()) {
    if (now - rec.updatedAt > TTL_MS) {
      ownedByVideoId.delete(videoId);
      continue;
    }
    const survivors = new Set<Element>();
    rec.containers.forEach((c) => {
      if (c && c.isConnected) survivors.add(c);
    });
    rec.containers = survivors;
    if (rec.containers.size < 1) ownedByVideoId.delete(videoId);
  }
}

/**
 * Re-discover container candidates for previously detected NSFW video IDs.
 * This is used by observer heartbeat/nav hooks to survive card recycling.
 */
export function refreshOwnedContainersFromDom(videoId: string, searchRoot: ParentNode = document): Element[] {
  if (!isValidVideoId(videoId) || !searchRoot) return [];
  const selectors = [
    `img[src*="ytimg.com/vi/${videoId}/"]`,
    `img[src*="i.ytimg.com/vi/${videoId}/"]`,
    `a[href*="watch?v=${videoId}"]`,
    `a[href*="/shorts/${videoId}"]`,
  ];

  const found = new Set<Element>();
  for (const selector of selectors) {
    const nodes = searchRoot.querySelectorAll(selector);
    for (const node of nodes) {
      const container =
        node.closest(
          [
            "ytd-rich-item-renderer",
            "ytd-video-renderer",
            "ytd-compact-video-renderer",
            "ytd-grid-video-renderer",
            "yt-lockup-view-model",
            "ytd-reel-item-renderer",
            "ytd-reel-shelf-renderer",
            "ytm-rich-item-renderer",
            "ytm-video-with-context-renderer",
            "ytm-compact-video-renderer",
            "ytm-shorts-lockup-view-model",
            "ytm-reel-video-renderer",
            "#shorts-player",
            "#content",
          ].join(",")
        ) || (node as Element);

      if (container && stampOwnership(container, videoId)) {
        registerOwnedVideo(videoId, container);
        found.add(container);
      }
    }
  }
  return Array.from(found);
}

/**
 * Hook target for observer heartbeat/nav rescans.
 * Kept here to meet requirement; actual blur application is injected by caller.
 */
export function reapplyAllBlurs(reapplyContainerFn: (container: Element, videoId: string) => void): void {
  pruneOwnedRegistry();
  for (const rec of ownedByVideoId.values()) {
    refreshOwnedContainersFromDom(rec.videoId);
    for (const container of getOwnedContainersForVideo(rec.videoId)) {
      try {
        reapplyContainerFn(container, rec.videoId);
      } catch {
        // Keep heartbeat resilient; never throw out of loop.
      }
    }
  }
}

/**
 * WebView testing notes:
 * - Scroll home feed until old cards unmount; verify `refreshOwnedContainersFromDom` restamps replacements.
 * - Switch tabs/search/results and return; confirm epoch bump + restamp still reapplies for owned IDs.
 * - Hover preview transitions (desktop) should retain ownership attrs on nearest card container.
 */

