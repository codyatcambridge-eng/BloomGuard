/**
 * R1–R16: RegularPositiveCardController test matrix
 *
 * Phase 2 (shadow mode). Both regularCardControllerShadowMode and
 * regularCardControllerEnabled default to false — the controller is inert.
 * These tests document baseline behavior across the three confirmed failure paths:
 *
 *   Path A: simultaneous video+sentinel replacement → no_blurred_context
 *   Path B: href_key_unknown during card transition → deny(href_key_unknown)
 *   Path C: 80ms cooldown blind window with rapid mutations
 *
 * Phase 3 will flip the flags and convert R-tests to enforcement assertions.
 */

import { describe, it, expect, afterEach } from 'vitest';
import {
  buildCard,
  buildReplacementFixture,
  buildRapidChurnFixture,
  buildShortsAdjacentFixture,
  stampPositiveBlur,
  clearReattachCooldown,
  injectScript,
  type InjectionResult,
} from './harness';

const POSITIVE_ID = 'dQw4w9WgXcQ';
const NEGATIVE_ID = 'negativeVid1';
const SHORTS_ID = 'ShortsVidAAA';

let injection: InjectionResult;

afterEach(() => {
  injection?.cleanup();
});

// ---------------------------------------------------------------------------
// R1–R4: Node replacement (Path A)
// ---------------------------------------------------------------------------

describe('R1: Node replacement — fresh video node after DOM swap', () => {
  it('R1a: diagNonShortsReattach does not throw when a fresh video has no card ancestor', () => {
    const orphan = document.createElement('video') as HTMLVideoElement;
    orphan.src = `https://i.ytimg.com/vi/${POSITIVE_ID}/hqdefault.jpg`;
    document.body.appendChild(orphan);
    injection = injectScript();

    clearReattachCooldown(orphan);
    expect(() => {
      injection.probe.diagNonShortsReattach(orphan, 'attr:style');
    }).not.toThrow();
  });

  it('R1b: original blurred video stays blurred through one diagNonShortsReattach cycle', () => {
    const { originalVideo } = buildReplacementFixture('ytm-rich-item-renderer', POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(originalVideo);
    injection.probe.diagNonShortsReattach(originalVideo, 'attr:style');

    expect(originalVideo.dataset.mwModerated).toBe('blurred');
  });

  it('R1c: replacement video after node swap can be diagnosed without throwing', () => {
    const { card, originalVideo, replacementVideo } = buildReplacementFixture('ytm-rich-item-renderer', POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(originalVideo);
    injection.probe.diagNonShortsReattach(originalVideo, 'attr:style');

    // Swap: remove original anchor, add replacement
    const anchor = originalVideo.closest('a');
    if (anchor) card.removeChild(anchor);
    const newAnchor = document.createElement('a');
    newAnchor.href = `/watch?v=${POSITIVE_ID}`;
    newAnchor.appendChild(replacementVideo);
    card.appendChild(newAnchor);

    clearReattachCooldown(replacementVideo);
    expect(() => {
      injection.probe.diagNonShortsReattach(replacementVideo, 'attr:style');
    }).not.toThrow();
  });
});

describe('R2: Sentinel-less replacement — card has no blurred context after full swap', () => {
  it('R2a: diagNonShortsReattach on orphaned fresh video (no sentinel) does not apply blur', () => {
    const { card, originalVideo } = buildReplacementFixture('ytm-rich-item-renderer', POSITIVE_ID);
    injection = injectScript();

    // Remove original (takes blur stamps with it)
    const anchor = originalVideo.closest('a');
    if (anchor) card.removeChild(anchor);

    const fresh = document.createElement('video') as HTMLVideoElement;
    fresh.src = `https://i.ytimg.com/vi/${POSITIVE_ID}/hqdefault.jpg`;
    card.appendChild(fresh);

    clearReattachCooldown(fresh);
    injection.probe.diagNonShortsReattach(fresh, 'attr:style');

    // Without any classifier_positive call, blur must not be applied
    expect(fresh.dataset.mwModerated).not.toBe('blurred');
  });
});

describe('R3: Poster URL change on same node', () => {
  it('R3a: poster mutation does not clear blur on a correctly stamped video', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(video);
    injection.probe.diagNonShortsReattach(video, 'attr:style');
    expect(video.dataset.mwModerated).toBe('blurred');

    video.poster = `https://i.ytimg.com/vi/${POSITIVE_ID}/mqdefault.jpg`;

    clearReattachCooldown(video);
    injection.logs.length = 0;
    injection.probe.diagNonShortsReattach(video, 'attr:style');

    expect(video.dataset.mwModerated).toBe('blurred');
  });
});

describe('R4: 20-cycle replacement stress', () => {
  it('R4a: 20 consecutive diagNonShortsReattach cycles never produce hard_blur_provenance_mismatch_cleared', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    const cleared: string[] = [];
    for (let i = 0; i < 20; i++) {
      clearReattachCooldown(video);
      injection.logs.length = 0;
      injection.probe.diagNonShortsReattach(video, 'attr:style');
      cleared.push(...injection.logs.filter(l => l.includes('hard_blur_provenance_mismatch_cleared')));
    }
    expect(cleared).toHaveLength(0);
  });
});

// ---------------------------------------------------------------------------
// R5–R8: href_key_unknown path (Path B)
// ---------------------------------------------------------------------------

describe('R5: href_key_unknown — getMvpCardHrefItemKey baseline', () => {
  it('R5a: returns unknown when card has no watch anchor', () => {
    const card = document.createElement('ytm-rich-item-renderer');
    document.body.appendChild(card);
    injection = injectScript();

    expect(injection.probe.getMvpCardHrefItemKey(card)).toBe('unknown');
  });

  it('R5b: returns the video ID from a card with a /watch?v= anchor', () => {
    const { card } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    injection = injectScript();

    expect(injection.probe.getMvpCardHrefItemKey(card)).toBe(POSITIVE_ID);
  });
});

describe('R6: isMvpBlurAuthorized denies unknown itemKey', () => {
  it('R6a: returns false when itemKey is "unknown"', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    const result = injection.probe.isMvpBlurAuthorized(
      video,
      `https://i.ytimg.com/vi/${POSITIVE_ID}/hqdefault.jpg`,
      'unknown',
      'classifier_positive',
      'r6a',
    );
    expect(result).toBe(false);
  });
});

describe('R7: href gap during transition', () => {
  it('R7a: removing anchor href and re-diagnosing does not throw', () => {
    const { video, anchor } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    if (anchor) anchor.removeAttribute('href');

    clearReattachCooldown(video);
    expect(() => {
      injection.probe.diagNonShortsReattach(video, 'attr:style');
    }).not.toThrow();
  });
});

// ---------------------------------------------------------------------------
// R9–R12: 80ms cooldown (Path C)
// ---------------------------------------------------------------------------

describe('R9: Cooldown behaviour', () => {
  it('R9a: second call without clearing cooldown produces fewer or equal log lines', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(video);
    injection.logs.length = 0;
    injection.probe.diagNonShortsReattach(video, 'attr:style');
    const firstCount = injection.logs.length;

    injection.logs.length = 0;
    injection.probe.diagNonShortsReattach(video, 'attr:style');
    const secondCount = injection.logs.length;

    expect(secondCount).toBeLessThanOrEqual(firstCount);
  });

  it('R9b: after clearReattachCooldown, call is not skipped (produces logs)', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(video);
    injection.probe.diagNonShortsReattach(video, 'attr:style');

    clearReattachCooldown(video);
    injection.logs.length = 0;
    injection.probe.diagNonShortsReattach(video, 'attr:style');

    expect(injection.logs.length).toBeGreaterThan(0);
  });
});

describe('R10: Cooldown with style mutation', () => {
  it('R10a: blur survives two rapid attr:style events when second is within cooldown', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    stampPositiveBlur(video, POSITIVE_ID);
    injection = injectScript();

    clearReattachCooldown(video);
    injection.probe.diagNonShortsReattach(video, 'attr:style');
    // Second call within cooldown — must not clear blur
    injection.probe.diagNonShortsReattach(video, 'attr:style');

    expect(video.dataset.mwModerated).toBe('blurred');
  });
});

// ---------------------------------------------------------------------------
// R13–R14: Negative isolation
// ---------------------------------------------------------------------------

describe('R13: Negative isolation — controller never blurs negatives', () => {
  it('R13a: fresh (never-blurred) video stays unblurred after diagNonShortsReattach', () => {
    const { video } = buildCard('ytm-rich-item-renderer', NEGATIVE_ID);
    injection = injectScript();

    clearReattachCooldown(video);
    injection.probe.diagNonShortsReattach(video, 'attr:style');

    expect(video.dataset.mwModerated).not.toBe('blurred');
    expect(video.style.filter || '').not.toMatch(/blur/);
  });

  it('R13b: isMvpBlurAuthorized denies when no ownership stamp is present', () => {
    const { video } = buildCard('ytm-rich-item-renderer', POSITIVE_ID);
    // No stampPositiveBlur — no ownership
    injection = injectScript();

    const result = injection.probe.isMvpBlurAuthorized(
      video,
      `https://i.ytimg.com/vi/${NEGATIVE_ID}/hqdefault.jpg`,
      NEGATIVE_ID,
      'classifier_positive',
      'r13b',
    );
    expect(result).toBe(false);
  });
});

describe('R14: Adjacent card isolation', () => {
  it('R14a: Shorts-adjacent card — positive retains blur, Shorts card has none', () => {
    const { positiveVideo, shortsCard } =
      buildShortsAdjacentFixture('ytm-rich-item-renderer', POSITIVE_ID, SHORTS_ID);
    injection = injectScript();

    clearReattachCooldown(positiveVideo);
    injection.probe.diagNonShortsReattach(positiveVideo, 'attr:style');

    expect(positiveVideo.dataset.mwModerated).toBe('blurred');

    const shortsVideo = shortsCard.querySelector('video') as HTMLVideoElement | null;
    if (shortsVideo) {
      expect(shortsVideo.dataset.mwModerated).not.toBe('blurred');
    }
  });
});

// ---------------------------------------------------------------------------
// R15–R16: URL surface guard
// ---------------------------------------------------------------------------

describe('R15: Surface URL guard', () => {
  it('R15a: isYouTubeMainPageThumbnailSurfaceUrl returns true for m.youtube.com home', () => {
    injection = injectScript();
    expect(
      injection.probe.isYouTubeMainPageThumbnailSurfaceUrl('https://m.youtube.com/'),
    ).toBe(true);
  });

  it('R15b: isYouTubeMainPageThumbnailSurfaceUrl returns false for Shorts playback URL', () => {
    injection = injectScript();
    expect(
      injection.probe.isYouTubeMainPageThumbnailSurfaceUrl('https://m.youtube.com/shorts/ShortsVidAAA'),
    ).toBe(false);
  });

  it('R15c: isYouTubeMainPageThumbnailSurfaceUrl returns true for /results search surface', () => {
    injection = injectScript();
    expect(
      injection.probe.isYouTubeMainPageThumbnailSurfaceUrl('https://m.youtube.com/results?search_query=test'),
    ).toBe(true);
  });
});

describe('R16: Rapid churn — 5 card cycles do not throw', () => {
  it('R16a: buildRapidChurnFixture cycling through 5 video IDs does not throw', () => {
    const ids = ['id1111111111', 'id2222222222', 'id3333333333', 'id4444444444', 'id5555555555'];
    const { card, videos } = buildRapidChurnFixture('ytm-rich-item-renderer', ids);
    injection = injectScript();

    expect(() => {
      for (let i = 0; i < videos.length; i++) {
        if (i > 0) {
          const prev = videos[i - 1];
          const prevAnchor = prev.closest('a');
          if (prevAnchor && prevAnchor.parentElement === card) {
            card.removeChild(prevAnchor);
          }
          const a = document.createElement('a');
          a.href = `/watch?v=${ids[i]}`;
          a.appendChild(videos[i]);
          card.appendChild(a);
        }
        clearReattachCooldown(videos[i]);
        injection.probe.diagNonShortsReattach(videos[i], 'attr:style');
      }
    }).not.toThrow();

    void card;
  });
});
